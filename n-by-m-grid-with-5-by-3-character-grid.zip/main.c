/* *****************************************************************************
**   Author: Mangaraju
     Problem Statement: Print a checker board (8-by-8 grid). Each square should be 5-by-3 characters wide. A 2-by-2 example follows:

            +-----+-----+ 
            |     |     | 
            |     |     | 
            |     |     | 
            +-----+-----+ 
            |     |     | 
            |     |     | 
            |     |     | 
            +-----+-----+
**   Usage: Enter grid size EX: 2 2  
**   Reponse: You will get a grid of 2 by 2 checker boaard with 5 by 3 character wide
**
**
**
**
**********************************************************************************/


#include<stdio.h>

int main(){
    int r,c;
    int nr,nc;
    char rc[10];
    printf("Enter n by m: ");
    fgets(rc, sizeof(rc),stdin);
    sscanf(rc,"%d %d", &r,&c);
    
    
    nc = (c+1)+(c*5);
    nr = (r+1)+(r*3);
    char ch[nr][nc];
    
    for(int i=0; i<nr;i++){
        for(int j =0; j<nc; j++){
            ch[i][j]=' ';
        }
        
    }
  
    for(int i=0; i<nr;i++){                        //Storing Columns with all " | "
        for(int j =0; j<nc; j=j+6){               // Later we replace 
            ch[i][j]= '|';
        }
        
    }
    
    for(int i=0; i<nr;i=i+4){                        //Storing rows
        for(int j =0; j<nc; j=j+1){
            ch[i][j]= '-';
        }
        
    }
    for(int i=0; i<nr;i=i+4){                        //Replacing rows with "+"
        for(int j =0; j<nc; j=j+6){
            ch[i][j]= '+';
        }
        
    }
    
     for(int i=0;i<nr;i++){                         /* print the 2-D array */
      for(int j=0;j<nc;j++){
          printf("%c",ch[i][j]);
      }
      printf("\n");
     }
  return 0;
}